import React from 'react';
import { View, StyleSheet } from 'react-native';
import { CartProvider } from './screens/CartContext';
import SplashScreen from './screens/SplashScreen';
import HomeScreen from './screens/HomeScreen';

export default function App() {
  const [showSplash, setShowSplash] = React.useState(true);

  React.useEffect(() => {
    setTimeout(() => {
      setShowSplash(false);
    }, 3000); // 3 seconds splash screen
  }, []);

  return (
    <CartProvider>
      <View style={styles.container}>
        {showSplash ? <SplashScreen /> : <HomeScreen />}
      </View>
    </CartProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});