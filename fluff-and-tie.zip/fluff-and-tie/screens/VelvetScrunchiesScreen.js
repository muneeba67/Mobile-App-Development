import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Image, 
  ScrollView, 
  Alert,
  StatusBar,
  Platform,
  ActivityIndicator 
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from './CartContext';
import { supabase } from './supabaseClient';

export default function VelvetScrunchiesScreen({ onClose, onOpenCart, onOpenProductDetail }) {
  const { addToCart, getCartCount } = useCart();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      console.log('📄 Fetching Velvet products...');
      setLoading(true);
      
      const data = await supabase.getProductsByCategory('Velvet');
      console.log('✅ Velvet products loaded:', data);
      
      const formattedProducts = data.map(product => ({
        ...product,
        image: { uri: product.image_url },
      }));
      
      setProducts(formattedProducts);
    } catch (error) {
      console.error('❌ Error fetching velvet products:', error);
      Alert.alert('Error', 'Failed to load products. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = (product) => {
    // ✅ CHECK STOCK BEFORE ADDING
    if (product.stock === 0) {
      Alert.alert('❌ Out of Stock', `${product.name} is currently out of stock.`);
      return;
    }

    addToCart(product);
    Alert.alert(
      '✅ Added to Cart!',
      `${product.name} has been added to your cart.`,
      [
        { text: 'Continue Shopping', style: 'cancel' },
        { 
          text: 'View Cart', 
          onPress: () => {
            onClose();
            setTimeout(() => onOpenCart(), 100);
          }
        }
      ]
    );
  };

  const handleProductClick = (product) => {
    console.log('🖱️ Product clicked:', product.name);
    onClose();
    setTimeout(() => {
      onOpenProductDetail(product);
    }, 100);
  };

  const handleCartClick = () => {
    onClose();
    setTimeout(() => onOpenCart(), 100);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFB6C1" />
      
      <LinearGradient
        colors={['#FFB6C1', '#FFDAB9', '#98D8C8', '#DDA0DD']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.header}
      >
        <TouchableOpacity 
          style={styles.backButton}
          onPress={onClose}
        >
          <Ionicons name="arrow-back" size={24} color="#333" />
          <Text style={styles.backText}>Back to Home</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.cartButton}
          onPress={handleCartClick}
        >
          <Ionicons name="cart" size={24} color="#333" />
          {getCartCount() > 0 && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{getCartCount()}</Text>
            </View>
          )}
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          <Text style={styles.title}>Velvet Scrunchies</Text>
          <Text style={styles.subtitle}>
            Luxurious velvet scrunchies that are soft on your hair and add elegance to any hairstyle.
          </Text>

          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#FF1493" />
              <Text style={styles.loadingText}>Loading products...</Text>
            </View>
          ) : products.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="ribbon-outline" size={80} color="#ccc" />
              <Text style={styles.emptyText}>No products available</Text>
            </View>
          ) : (
            <View style={styles.productsGrid}>
              {products.map((product) => (
                <TouchableOpacity 
                  key={product.id} 
                  style={styles.productCard}
                  onPress={() => handleProductClick(product)}
                  activeOpacity={0.9}
                >
                  {/* ✅ PRODUCT IMAGE WITH STOCK BADGE */}
                  <View style={styles.imageContainer}>
                    <Image 
                      source={product.image} 
                      style={styles.productImage}
                    />
                    
                    {/* ✅ OUT OF STOCK BADGE */}
                    {product.stock === 0 && (
                      <View style={styles.outOfStockBadge}>
                        <Text style={styles.outOfStockText}>OUT OF STOCK</Text>
                      </View>
                    )}
                    
                    {/* ✅ LOW STOCK BADGE */}
                    {product.stock > 0 && product.stock <= 5 && (
                      <View style={styles.lowStockBadge}>
                        <Ionicons name="warning" size={12} color="#fff" />
                        <Text style={styles.lowStockText}>Only {product.stock} left!</Text>
                      </View>
                    )}
                  </View>

                  <Text style={styles.productName}>{product.name}</Text>
                  <Text style={styles.productPrice}>Rs. {product.price}</Text>
                  
                  {/* ✅ ADD TO CART BUTTON (DISABLED IF OUT OF STOCK) */}
                  <TouchableOpacity
                    style={[
                      styles.addToCartBtn,
                      product.stock === 0 && styles.disabledBtn
                    ]}
                    onPress={(e) => {
                      e.stopPropagation();
                      handleAddToCart(product);
                    }}
                    activeOpacity={product.stock === 0 ? 1 : 0.8}
                    disabled={product.stock === 0}
                  >
                    <Ionicons 
                      name={product.stock === 0 ? "close-circle" : "cart"} 
                      size={18} 
                      color="#fff" 
                      style={styles.cartIcon} 
                    />
                    <Text style={styles.addToCartText}>
                      {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                    </Text>
                  </TouchableOpacity>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF5F8',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 12,
    paddingTop: Platform.OS === 'ios' ? 50 : StatusBar.currentHeight + 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 5,
  },
  backText: {
    color: '#333',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 5,
  },
  cartButton: {
    position: 'relative',
    padding: 5,
  },
  cartBadge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF1493',
    borderRadius: 10,
    width: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 25,
    lineHeight: 24,
  },
  loadingContainer: {
    paddingVertical: 50,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  emptyContainer: {
    paddingVertical: 50,
    alignItems: 'center',
  },
  emptyText: {
    marginTop: 15,
    fontSize: 16,
    color: '#999',
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productCard: {
    width: '48%',
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 12,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  // ✅ NEW STYLES FOR STOCK MANAGEMENT
  imageContainer: {
    position: 'relative',
    width: '100%',
    height: 150,
    marginBottom: 10,
  },
  productImage: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
    resizeMode: 'cover',
    backgroundColor: '#f0f0f0',
  },
  outOfStockBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#FF0000',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    elevation: 3,
  },
  outOfStockText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  lowStockBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#FFA500',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    elevation: 3,
  },
  lowStockText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  productName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF1493',
    marginBottom: 10,
    textAlign: 'center',
  },
  addToCartBtn: {
    backgroundColor: '#FF1493',
    paddingVertical: 10,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabledBtn: {
    backgroundColor: '#999',
    opacity: 0.7,
  },
  cartIcon: {
    marginRight: 5,
  },
  addToCartText: {
    color: '#fff',
    fontSize: 13,
    fontWeight: 'bold',
  },
});