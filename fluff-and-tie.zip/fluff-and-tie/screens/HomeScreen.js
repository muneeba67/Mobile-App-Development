import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  StatusBar,
  Platform,
  TextInput,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from './CartContext';
import { supabase } from './supabaseClient';
import CartScreen from './CartScreen';
import VelvetScrunchiesScreen from './VelvetScrunchiesScreen';
import SilkScrunchiesScreen from './SilkScrunchiesScreen';
import FloralScrunchiesScreen from './FloralScrunchiesScreen';
import ProductDetailScreen from './ProductDetailScreen';
import CheckoutScreen from './CheckoutScreen';
import ContactScreen from './ContactScreen';

const { width, height } = Dimensions.get('window');

export default function HomeScreen() {
  const { getCartCount } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [shopExpanded, setShopExpanded] = useState(false);
  const [contactExpanded, setContactExpanded] = useState(false);
  const [searchVisible, setSearchVisible] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [cartVisible, setCartVisible] = useState(false);
  const [velvetVisible, setVelvetVisible] = useState(false);
  const [silkVisible, setSilkVisible] = useState(false);
  const [floralVisible, setFloralVisible] = useState(false);
  const [productDetailVisible, setProductDetailVisible] = useState(false);
  const [checkoutVisible, setCheckoutVisible] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [contactVisible, setContactVisible] = useState(false);
  const [previousScreen, setPreviousScreen] = useState('home');

  // ✅ Real-time search function
  const handleSearch = async (text) => {
    setSearchText(text);
    
    if (text.trim().length === 0) {
      setSearchResults([]);
      setSearching(false);
      return;
    }

    if (text.trim().length < 2) {
      return;
    }

    try {
      setSearching(true);
      console.log('🔍 Searching for:', text);
      
      const results = await supabase.searchProducts(text.trim());
      
      // Format results to match ProductDetailScreen expectations
      const formattedResults = results.map(product => ({
        ...product,
        image: { uri: product.image_url },
      }));
      
      setSearchResults(formattedResults);
      console.log('✅ Search results:', formattedResults);
    } catch (error) {
      console.error('❌ Search error:', error);
      setSearchResults([]);
    } finally {
      setSearching(false);
    }
  };

  const openProductFromSearch = (product) => {
    setSelectedProduct(product);
    setSearchVisible(false);
    setSearchText('');
    setSearchResults([]);
    setTimeout(() => {
      setProductDetailVisible(true);
    }, 100);
  };

  const openCartFrom = (screenName) => {
    setPreviousScreen(screenName);
    setCartVisible(true);
  };

  const closeCartAndReturn = () => {
    setCartVisible(false);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFB6C1" />
      
      <LinearGradient
        colors={['#FFB6C1', '#FFDAB9', '#98D8C8', '#DDA0DD']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.header}
      >
        <TouchableOpacity
          style={styles.menuIcon}
          onPress={() => setMenuOpen(!menuOpen)}
        >
          <Ionicons name={menuOpen ? "close" : "menu"} size={28} color="#333" />
        </TouchableOpacity>

        <Text style={styles.logo}>FLUFF N TIE</Text>

        <View style={styles.rightIcons}>
          <TouchableOpacity 
            style={styles.iconButton}
            onPress={() => setSearchVisible(true)}
          >
            <Ionicons name="search" size={24} color="#333" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.iconButton}
            onPress={() => openCartFrom('home')}
          >
            <Ionicons name="cart" size={24} color="#333" />
            {getCartCount() > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{getCartCount()}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </LinearGradient>

      {/* ✅ FIXED Search Modal with Real-time Search */}
      <Modal
        visible={searchVisible}
        animationType="fade"
        transparent={true}
        onRequestClose={() => {
          setSearchVisible(false);
          setSearchText('');
          setSearchResults([]);
        }}
      >
        <View style={styles.searchModal}>
          <View style={styles.searchContainer}>
            <LinearGradient
              colors={['#FFB6C1', '#FFDAB9', '#98D8C8', '#DDA0DD']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.searchHeader}
            >
              <TouchableOpacity
                onPress={() => {
                  setSearchVisible(false);
                  setSearchText('');
                  setSearchResults([]);
                }}
                style={styles.closeSearch}
              >
                <Ionicons name="arrow-back" size={24} color="#333" />
              </TouchableOpacity>
              
              <View style={styles.searchInputContainer}>
                <Ionicons name="search" size={20} color="#999" />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search scrunchies..."
                  placeholderTextColor="#999"
                  value={searchText}
                  onChangeText={handleSearch}
                  autoFocus={true}
                />
                {searchText.length > 0 && (
                  <TouchableOpacity onPress={() => {
                    setSearchText('');
                    setSearchResults([]);
                  }}>
                    <Ionicons name="close-circle" size={20} color="#999" />
                  </TouchableOpacity>
                )}
              </View>
            </LinearGradient>

            <ScrollView style={styles.searchResults}>
              {searching ? (
                <View style={styles.searchLoadingContainer}>
                  <ActivityIndicator size="large" color="#FF1493" />
                  <Text style={styles.searchLoadingText}>Searching...</Text>
                </View>
              ) : searchText.length > 0 && searchText.length < 2 ? (
                <View style={styles.searchResultItem}>
                  <Text style={styles.noResults}>Type at least 2 characters...</Text>
                </View>
              ) : searchResults.length > 0 ? (
                <View style={styles.resultsContainer}>
                  <Text style={styles.resultsTitle}>
                    Found {searchResults.length} product{searchResults.length !== 1 ? 's' : ''}
                  </Text>
                  {searchResults.map((product) => (
                    <TouchableOpacity
                      key={product.id}
                      style={styles.resultCard}
                      onPress={() => openProductFromSearch(product)}
                      activeOpacity={0.8}
                    >
                      <Image source={product.image} style={styles.resultImage} />
                      <View style={styles.resultInfo}>
                        <Text style={styles.resultName}>{product.name}</Text>
                        <Text style={styles.resultCategory}>{product.category}</Text>
                        <Text style={styles.resultPrice}>Rs. {product.price}</Text>
                      </View>
                      <Ionicons name="chevron-forward" size={20} color="#999" />
                    </TouchableOpacity>
                  ))}
                </View>
              ) : searchText.length >= 2 ? (
                <View style={styles.searchResultItem}>
                  <Ionicons name="sad-outline" size={60} color="#ccc" />
                  <Text style={styles.noResults}>No products found</Text>
                  <Text style={styles.noResultsSubtext}>
                    Try searching with different keywords
                  </Text>
                </View>
              ) : (
                <View style={styles.searchSuggestions}>
                  <Text style={styles.suggestionsTitle}>Popular Categories</Text>
                  <TouchableOpacity 
                    style={styles.suggestionItem}
                    onPress={() => handleSearch('Velvet')}
                  >
                    <Ionicons name="search" size={16} color="#FF1493" />
                    <Text style={styles.suggestionText}>Velvet Scrunchies</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.suggestionItem}
                    onPress={() => handleSearch('Silk')}
                  >
                    <Ionicons name="search" size={16} color="#FF1493" />
                    <Text style={styles.suggestionText}>Silk Scrunchies</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.suggestionItem}
                    onPress={() => handleSearch('Floral')}
                  >
                    <Ionicons name="search" size={16} color="#FF1493" />
                    <Text style={styles.suggestionText}>Floral Scrunchies</Text>
                  </TouchableOpacity>
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Cart Modal */}
      <Modal
        visible={cartVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={closeCartAndReturn}
      >
        <CartScreen 
          onClose={closeCartAndReturn}
          previousScreen={previousScreen}
          onOpenCheckout={() => {
            setCartVisible(false);
            setTimeout(() => setCheckoutVisible(true), 100);
          }}
        />
      </Modal>

      {/* Checkout Modal */}
      <Modal
        visible={checkoutVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setCheckoutVisible(false)}
      >
        <CheckoutScreen 
          onClose={() => setCheckoutVisible(false)}
          onOpenCart={() => {
            setCheckoutVisible(false);
            setTimeout(() => setCartVisible(true), 100);
          }}
        />
      </Modal>

      {/* Product Detail Modal */}
      <Modal
        visible={productDetailVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setProductDetailVisible(false)}
      >
        <ProductDetailScreen 
          product={selectedProduct}
          onClose={() => setProductDetailVisible(false)}
          onOpenCart={() => {
            setPreviousScreen('productDetail');
            setCartVisible(true);
          }}
          onOpenContact={() => {
            setProductDetailVisible(false);
            setTimeout(() => setContactVisible(true), 100);
          }}
        />
      </Modal>

      {/* Contact Modal */}
      <Modal
        visible={contactVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setContactVisible(false)}
      >
        <ContactScreen 
          onClose={() => setContactVisible(false)}
          onOpenCart={() => {
            setContactVisible(false);
            setTimeout(() => setCartVisible(true), 100);
          }}
        />
      </Modal>

      {/* Velvet Scrunchies Modal */}
      <Modal
        visible={velvetVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setVelvetVisible(false)}
      >
        <VelvetScrunchiesScreen 
          onClose={() => setVelvetVisible(false)}
          onOpenCart={() => {
            setVelvetVisible(false);
            setTimeout(() => openCartFrom('home'), 100);
          }}
          onOpenProductDetail={(product) => {
            setSelectedProduct(product);
            setProductDetailVisible(true);
          }}
        />
      </Modal>

      {/* Silk Scrunchies Modal */}
      <Modal
        visible={silkVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setSilkVisible(false)}
      >
        <SilkScrunchiesScreen 
          onClose={() => setSilkVisible(false)}
          onOpenCart={() => {
            setSilkVisible(false);
            setTimeout(() => openCartFrom('home'), 100);
          }}
          onOpenProductDetail={(product) => {
            setSelectedProduct(product);
            setProductDetailVisible(true);
          }}
        />
      </Modal>

      {/* Floral Scrunchies Modal */}
      <Modal
        visible={floralVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setFloralVisible(false)}
      >
        <FloralScrunchiesScreen 
          onClose={() => setFloralVisible(false)}
          onOpenCart={() => {
            setFloralVisible(false);
            setTimeout(() => openCartFrom('home'), 100);
          }}
          onOpenProductDetail={(product) => {
            setSelectedProduct(product);
            setProductDetailVisible(true);
          }}
        />
      </Modal>

      <View style={styles.mainContent}>
        {/* Sidebar Menu */}
        {menuOpen && (
          <>
            <TouchableOpacity
              style={styles.overlay}
              activeOpacity={1}
              onPress={() => setMenuOpen(false)}
            />
            
            <View style={styles.sidebar}>
              <View style={styles.sidebarHeader}>
                <Text style={styles.sidebarTitle}>Menu</Text>
              </View>

              <ScrollView style={styles.menuScroll}>
                <TouchableOpacity 
                  style={styles.menuItem}
                  onPress={() => setMenuOpen(false)}
                >
                  <Text style={styles.menuText}>Home</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => setShopExpanded(!shopExpanded)}
                >
                  <View style={styles.menuItemContent}>
                    <Text style={[styles.menuText, styles.activeMenu]}>Shop</Text>
                    <Ionicons
                      name={shopExpanded ? 'chevron-down' : 'chevron-forward'}
                      size={20}
                      color="#FF1493"
                    />
                  </View>
                </TouchableOpacity>

                {shopExpanded && (
                  <View style={styles.dropdown}>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => {
                        setMenuOpen(false);
                        setFloralVisible(true);
                      }}
                    >
                      <Text style={styles.dropdownText}>Floral Prints Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => {
                        setMenuOpen(false);
                        setVelvetVisible(true);
                      }}
                    >
                      <Text style={styles.dropdownText}>Velvet Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => {
                        setMenuOpen(false);
                        setSilkVisible(true);
                      }}
                    >
                      <Text style={styles.dropdownText}>Silk Scrunchies</Text>
                    </TouchableOpacity>
                  </View>
                )}

                <TouchableOpacity 
                  style={styles.menuItem}
                  onPress={() => {
                    setMenuOpen(false);
                    setContactVisible(true);
                  }}
                >
                  <Text style={styles.menuText}>Contact</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          </>
        )}

        {/* Main Scrollable Content */}
        <ScrollView 
          style={styles.contentArea}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          bounces={true}
        >
          {/* Hero Banner */}
          <View style={styles.heroSection}>
            <Image
              source={require('../assets/banner.jpeg')}
              style={styles.bannerImage}
              resizeMode="cover"
            />
          </View>

          {/* OUR COLLECTION Section */}
          <View style={styles.collectionHeader}>
            <Text style={styles.collectionTitle}>OUR COLLECTION</Text>
          </View>

          {/* Velvet Scrunchies Section */}
          <View style={styles.productSection}>
            <Text style={styles.productTitle}>Velvet Scrunchies</Text>
            <TouchableOpacity 
              activeOpacity={0.9}
              onPress={() => setVelvetVisible(true)}
            >
              <Image
                source={require('../assets/velvetscrunchie.jfif')}
                style={styles.productImage}
                resizeMode="cover"
              />
            </TouchableOpacity>
          </View>

          {/* Silk Scrunchies Section */}
          <View style={styles.productSection}>
            <Text style={styles.productTitle}>Silk Scrunchies</Text>
            <TouchableOpacity 
              activeOpacity={0.9}
              onPress={() => setSilkVisible(true)}
            >
              <Image
                source={require('../assets/SlikScrunchie.jfif')}
                style={styles.productImage}
                resizeMode="cover"
              />
            </TouchableOpacity>
          </View>

          {/* Floral Scrunchies Section */}
          <View style={styles.productSection}>
            <Text style={styles.productTitle}>Floral Scrunchies</Text>
            <TouchableOpacity 
              activeOpacity={0.9}
              onPress={() => setFloralVisible(true)}
            >
              <Image
                source={require('../assets/FloralScrunchie.jfif')}
                style={styles.productImage}
                resizeMode="cover"
              />
            </TouchableOpacity>
          </View>

          {/* Contact Us Section */}
          <View style={styles.contactSection}>
            <TouchableOpacity
              style={styles.contactHeader}
              onPress={() => setContactExpanded(!contactExpanded)}
              activeOpacity={0.7}
            >
              <Text style={styles.contactTitle}>CONTACT US</Text>
              <Ionicons
                name={contactExpanded ? 'remove' : 'add'}
                size={28}
                color="#333"
              />
            </TouchableOpacity>

            {contactExpanded && (
              <View style={styles.contactDetails}>
                <View style={styles.contactItem}>
                  <Ionicons name="call" size={24} color="#FF1493" />
                  <Text style={styles.contactText}>0343 6689390</Text>
                </View>
                <View style={styles.contactItem}>
                  <Ionicons name="mail" size={24} color="#FF1493" />
                  <Text style={styles.contactText}>fluffandtie3@gmail.com</Text>
                </View>
              </View>
            )}
          </View>

          {/* Social Icons */}
          <View style={styles.socialContainer}>
            <TouchableOpacity style={styles.socialIcon} activeOpacity={0.7}>
              <Ionicons name="logo-whatsapp" size={40} color="#25D366" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialIcon} activeOpacity={0.7}>
              <Ionicons name="logo-instagram" size={40} color="#E4405F" />
            </TouchableOpacity>
          </View>

          {/* Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>© 2025, Fluff N Tie</Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 12,
    paddingTop: Platform.OS === 'ios' ? 50 : StatusBar.currentHeight + 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    zIndex: 100,
  },
  menuIcon: {
    padding: 5,
    width: 40,
  },
  logo: {
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 3,
    color: '#FF1493',
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  rightIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    marginLeft: 15,
    position: 'relative',
    padding: 5,
  },
  badge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF1493',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  searchModal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  searchContainer: {
    backgroundColor: '#fff',
    flex: 1,
  },
  searchHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    paddingVertical: 12,
    paddingTop: Platform.OS === 'ios' ? 50 : StatusBar.currentHeight + 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  closeSearch: {
    padding: 5,
    marginRight: 10,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  searchInput: {
    flex: 1,
    marginLeft: 10,
    fontSize: 16,
    color: '#333',
  },
  searchResults: {
    flex: 1,
    backgroundColor: '#f9f9f9',
  },
  searchLoadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  searchLoadingText: {
    marginTop: 15,
    fontSize: 16,
    color: '#666',
  },
  searchResultItem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  noResults: {
    fontSize: 18,
    color: '#333',
    fontWeight: '600',
    marginTop: 15,
    marginBottom: 8,
  },
  noResultsSubtext: {
    fontSize: 14,
    color: '#999',
  },
  resultsContainer: {
    padding: 15,
  },
  resultsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 15,
    paddingHorizontal: 5,
  },
  resultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  resultImage: {
    width: 70,
    height: 70,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
  },
  resultInfo: {
    flex: 1,
    marginLeft: 12,
  },
  resultName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  resultCategory: {
    fontSize: 12,
    color: '#999',
    marginBottom: 4,
  },
  resultPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF1493',
  },
  searchSuggestions: {
    padding: 20,
  },
  suggestionsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 15,
  },
  suggestionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 5,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  suggestionText: {
    fontSize: 15,
    color: '#666',
    marginLeft: 12,
  },
  mainContent: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 9,
  },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#fff',
    zIndex: 10,
    elevation: 16,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  sidebarHeader: {
    backgroundColor: '#FFB6C1',
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sidebarTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: 1,
  },
  menuScroll: {
    flex: 1,
  },
  menuItem: {
    paddingVertical: 16,
    paddingHorizontal: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  menuText: {
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
  },
  activeMenu: {
    color: '#FF1493',
    fontWeight: '600',
  },
  dropdown: {
    backgroundColor: '#FFF0F5',
    paddingLeft: 20,
  },
  dropdownItem: {
    paddingVertical: 14,
    paddingHorizontal: 25,
  },
  dropdownText: {
    fontSize: 14,
    color: '#666',
  },
  contentArea: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  heroSection: {
    width: '100%',
    height: height * 0.4,
    backgroundColor: '#f0f0f0',
  },
  bannerImage: {
    width: '100%',
    height: '100%',
  },
  collectionHeader: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: '#fff',
  },
  collectionTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    letterSpacing: 3,
    color: '#333',
  },
  productSection: {
    marginBottom: 30,
    paddingHorizontal: 15,
  },
  productTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#333',
    marginBottom: 15,
    letterSpacing: 1,
  },
  productImage: {
    width: '100%',
    height: 300,
    borderRadius: 10,
    backgroundColor: '#f0f0f0',
  },
  contactSection: {
    marginHorizontal: 15,
    marginTop: 20,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  contactHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  contactTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 1,
    color: '#333',
  },
  contactDetails: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  contactText: {
    fontSize: 16,
    color: '#666',
    marginLeft: 15,
  },
  socialContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 25,
    gap: 30,
  },
  socialIcon: {
    padding: 10,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 25,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    marginTop: 20,
    backgroundColor: '#fafafa',
  },
  footerText: {
    color: '#888',
    fontSize: 13,
    letterSpacing: 0.5,
  },
});
  