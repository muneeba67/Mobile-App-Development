import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Platform,
  StatusBar,
  Alert,
  Linking,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from './CartContext';
import { supabase } from './supabaseClient'; // ✅ Import

export default function ContactScreen({ onClose, onOpenCart }) {
  const { getCartCount } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [shopExpanded, setShopExpanded] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false); // ✅ Loading state

  const handleSendMessage = async () => {
    // Validation
    if (!name.trim() || !email.trim() || !message.trim()) {
      Alert.alert('Missing Information', 'Please fill in all fields.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      Alert.alert('Invalid Email', 'Please enter a valid email address.');
      return;
    }

    // ✅ Send to Supabase Backend
    try {
      setLoading(true);
      console.log('📤 Submitting contact form...');

      const contactData = {
        name: name.trim(),
        email: email.trim(),
        message: message.trim()
      };

      await supabase.createContact(contactData);

      console.log('✅ Contact form submitted successfully');

      // Success alert
      Alert.alert(
        '✅ Message Sent!',
        'Thank you for contacting us. We will get back to you soon!',
        [
          {
            text: 'OK',
            onPress: () => {
              // Clear form
              setName('');
              setEmail('');
              setMessage('');
            },
          },
        ]
      );
    } catch (error) {
      console.error('❌ Error submitting contact form:', error);
      Alert.alert(
        '❌ Error',
        'Failed to send message. Please try again or contact us directly.',
        [
          { text: 'OK', style: 'cancel' }
        ]
      );
    } finally {
      setLoading(false);
    }
  };

  const handlePhonePress = () => {
    Linking.openURL('tel:03436689390');
  };

  const handleEmailPress = () => {
    Linking.openURL('mailto:fluffandtie3@gmail.com');
  };

  const handleWhatsAppPress = () => {
    Linking.openURL('https://wa.me/923436689390');
  };

  const handleInstagramPress = () => {
    Linking.openURL('https://instagram.com/fluffandtie');
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFB6C1" />

      {/* Header */}
      <LinearGradient
        colors={['#FFB6C1', '#FFDAB9', '#98D8C8', '#DDA0DD']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.header}
      >
        <TouchableOpacity
          style={styles.menuIcon}
          onPress={() => setMenuOpen(!menuOpen)}
        >
          <Ionicons name={menuOpen ? "close" : "menu"} size={28} color="#333" />
        </TouchableOpacity>

        <Text style={styles.logo}>FLUFF N TIE</Text>

        <View style={styles.rightIcons}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="search" size={24} color="#333" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.iconButton}
            onPress={onOpenCart}
          >
            <Ionicons name="cart" size={24} color="#333" />
            {getCartCount() > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{getCartCount()}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <View style={styles.mainContent}>
        {/* Sidebar Menu */}
        {menuOpen && (
          <>
            <TouchableOpacity
              style={styles.overlay}
              activeOpacity={1}
              onPress={() => setMenuOpen(false)}
            />

            <View style={styles.sidebar}>
              <View style={styles.sidebarHeader}>
                <Text style={styles.sidebarTitle}>Menu</Text>
              </View>

              <ScrollView style={styles.menuScroll}>
                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => {
                    setMenuOpen(false);
                    onClose();
                  }}
                >
                  <Text style={styles.menuText}>Home</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => setShopExpanded(!shopExpanded)}
                >
                  <View style={styles.menuItemContent}>
                    <Text style={styles.menuText}>Shop</Text>
                    <Ionicons
                      name={shopExpanded ? 'chevron-down' : 'chevron-forward'}
                      size={20}
                      color="#333"
                    />
                  </View>
                </TouchableOpacity>

                {shopExpanded && (
                  <View style={styles.dropdown}>
                    <TouchableOpacity
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Floral Prints Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Velvet Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Silk Scrunchies</Text>
                    </TouchableOpacity>
                  </View>
                )}

                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => setMenuOpen(false)}
                >
                  <Text style={[styles.menuText, styles.activeMenu]}>Contact</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          </>
        )}

        {/* Main Content */}
        <ScrollView style={styles.contentArea} showsVerticalScrollIndicator={false}>
          {/* Back Link */}
          <TouchableOpacity style={styles.backLink} onPress={onClose}>
            <Ionicons name="arrow-back" size={16} color="#FF1493" />
            <Text style={styles.backLinkText}>Back to Home</Text>
          </TouchableOpacity>

          <View style={styles.contactContainer}>
            {/* Contact Form */}
            <View style={styles.formSection}>
              <Text style={styles.formTitle}>Get In Touch</Text>
              <Text style={styles.formSubtitle}>
                Send us a message and we'll respond as soon as possible!
              </Text>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Name *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Your Name"
                  placeholderTextColor="#999"
                  value={name}
                  onChangeText={setName}
                  autoCapitalize="words"
                  editable={!loading}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Email *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="your.email@example.com"
                  placeholderTextColor="#999"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  editable={!loading}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.label}>Message *</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Write your message here..."
                  placeholderTextColor="#999"
                  value={message}
                  onChangeText={setMessage}
                  multiline
                  numberOfLines={5}
                  textAlignVertical="top"
                  editable={!loading}
                />
              </View>

              <TouchableOpacity 
                style={[styles.sendButton, loading && styles.sendButtonDisabled]} 
                onPress={handleSendMessage}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <ActivityIndicator size="small" color="#fff" />
                    <Text style={styles.sendButtonText}>SENDING...</Text>
                  </>
                ) : (
                  <>
                    <Ionicons name="send" size={20} color="#fff" />
                    <Text style={styles.sendButtonText}>SEND MESSAGE</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>

            {/* Contact Info */}
            <View style={styles.infoSection}>
              <Text style={styles.infoTitle}>Contact Info</Text>

              <TouchableOpacity 
                style={styles.infoCard}
                onPress={handlePhonePress}
                activeOpacity={0.7}
              >
                <View style={styles.infoIconContainer}>
                  <Ionicons name="call" size={28} color="#FF1493" />
                </View>
                <View style={styles.infoTextContainer}>
                  <Text style={styles.infoLabel}>Phone</Text>
                  <Text style={styles.infoValue}>0343 6689390</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.infoCard}
                onPress={handleEmailPress}
                activeOpacity={0.7}
              >
                <View style={styles.infoIconContainer}>
                  <Ionicons name="mail" size={28} color="#FF1493" />
                </View>
                <View style={styles.infoTextContainer}>
                  <Text style={styles.infoLabel}>Email</Text>
                  <Text style={styles.infoValue}>fluffandtie3@gmail.com</Text>
                </View>
              </TouchableOpacity>

              <View style={styles.infoCard}>
                <View style={styles.infoIconContainer}>
                  <Ionicons name="location" size={28} color="#FF1493" />
                </View>
                <View style={styles.infoTextContainer}>
                  <Text style={styles.infoLabel}>Location</Text>
                  <Text style={styles.infoValue}>Rawalpindi, Pakistan</Text>
                </View>
              </View>

              <View style={styles.socialSection}>
                <TouchableOpacity 
                  style={styles.socialButton}
                  onPress={handleWhatsAppPress}
                  activeOpacity={0.7}
                >
                  <Ionicons name="logo-whatsapp" size={24} color="#25D366" />
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.socialButton}
                  onPress={handleInstagramPress}
                  activeOpacity={0.7}
                >
                  <Ionicons name="logo-instagram" size={24} color="#E4405F" />
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>© 2025, Fluff N Tie</Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 12,
    paddingTop: Platform.OS === 'ios' ? 50 : StatusBar.currentHeight + 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    zIndex: 100,
  },
  menuIcon: {
    padding: 5,
    width: 40,
  },
  logo: {
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 3,
    color: '#FF1493',
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  rightIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    marginLeft: 15,
    position: 'relative',
    padding: 5,
  },
  badge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF1493',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  mainContent: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 9,
  },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#fff',
    zIndex: 10,
    elevation: 16,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  sidebarHeader: {
    backgroundColor: '#FFB6C1',
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sidebarTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: 1,
  },
  menuScroll: {
    flex: 1,
  },
  menuItem: {
    paddingVertical: 16,
    paddingHorizontal: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  menuText: {
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
  },
  activeMenu: {
    color: '#FF1493',
    fontWeight: '600',
  },
  dropdown: {
    backgroundColor: '#FFF0F5',
    paddingLeft: 20,
  },
  dropdownItem: {
    paddingVertical: 14,
    paddingHorizontal: 25,
  },
  dropdownText: {
    fontSize: 14,
    color: '#666',
  },
  contentArea: {
    flex: 1,
    backgroundColor: '#FFF0F5',
  },
  backLink: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
  },
  backLinkText: {
    color: '#FF1493',
    fontSize: 14,
    marginLeft: 5,
    fontWeight: '500',
  },
  contactContainer: {
    padding: 15,
  },
  formSection: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  formTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  formSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 25,
    lineHeight: 20,
  },
  inputGroup: {
    marginBottom: 18,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 15,
    color: '#333',
    backgroundColor: '#fafafa',
  },
  textArea: {
    height: 120,
    textAlignVertical: 'top',
  },
  sendButton: {
    backgroundColor: '#FF1493',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 25,
    marginTop: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    gap: 10,
  },
  sendButtonDisabled: {
    opacity: 0.6,
  },
  sendButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  infoSection: {
    backgroundColor: '#9B59B6',
    borderRadius: 15,
    padding: 25,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  infoTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
  },
  infoIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  infoTextContainer: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 4,
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  socialSection: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 20,
    marginTop: 10,
  },
  socialButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 25,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    marginTop: 20,
    backgroundColor: '#fafafa',
  },
  footerText: {
    color: '#888',
    fontSize: 13,
    letterSpacing: 0.5,
  },
});