import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
  StatusBar,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from './CartContext';

export default function CartScreen({ onClose, previousScreen = 'home', onOpenCheckout }) {
  const { cartItems, getCartCount, getCartTotal, updateQuantity, removeFromCart, clearCart } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [shopExpanded, setShopExpanded] = useState(false);

  const SHIPPING_COST = 190;

  const handleRemoveItem = (productId, productName) => {
    Alert.alert(
      'Remove Item',
      `Remove ${productName} from cart?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Remove', 
          style: 'destructive',
          onPress: () => removeFromCart(productId)
        }
      ]
    );
  };

  const handleCheckout = () => {
    if (cartItems.length === 0) {
      Alert.alert('Empty Cart', 'Your cart is empty. Please add items before checkout.');
      return;
    }
    
    // Navigate to checkout screen
    onOpenCheckout();
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFB6C1" />
      
      {/* Header - Same as HomeScreen */}
      <LinearGradient
        colors={['#FFB6C1', '#FFDAB9', '#98D8C8', '#DDA0DD']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.header}
      >
        {/* Menu Icon */}
        <TouchableOpacity
          style={styles.menuIcon}
          onPress={() => setMenuOpen(!menuOpen)}
        >
          <Ionicons name={menuOpen ? "close" : "menu"} size={28} color="#333" />
        </TouchableOpacity>

        {/* Logo */}
        <Text style={styles.logo}>FLUFF N TIE</Text>

        {/* Right Icons */}
        <View style={styles.rightIcons}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="search" size={24} color="#333" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="cart" size={24} color="#333" />
            {getCartCount() > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{getCartCount()}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <View style={styles.mainContent}>
        {/* Sidebar Menu - Same as HomeScreen */}
        {menuOpen && (
          <>
            <TouchableOpacity
              style={styles.overlay}
              activeOpacity={1}
              onPress={() => setMenuOpen(false)}
            />
            
            <View style={styles.sidebar}>
              <View style={styles.sidebarHeader}>
                <Text style={styles.sidebarTitle}>Menu</Text>
              </View>

              <ScrollView style={styles.menuScroll}>
                <TouchableOpacity 
                  style={styles.menuItem}
                  onPress={() => {
                    setMenuOpen(false);
                    onClose();
                  }}
                >
                  <Text style={styles.menuText}>Home</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => setShopExpanded(!shopExpanded)}
                >
                  <View style={styles.menuItemContent}>
                    <Text style={[styles.menuText, styles.activeMenu]}>Shop</Text>
                    <Ionicons
                      name={shopExpanded ? 'chevron-down' : 'chevron-forward'}
                      size={20}
                      color="#FF1493"
                    />
                  </View>
                </TouchableOpacity>

                {shopExpanded && (
                  <View style={styles.dropdown}>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Floral Prints Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Velvet Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Silk Scrunchies</Text>
                    </TouchableOpacity>
                  </View>
                )}

                <TouchableOpacity 
                  style={styles.menuItem}
                  onPress={() => setMenuOpen(false)}
                >
                  <Text style={styles.menuText}>Contact</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          </>
        )}

        {/* Cart Content */}
        <ScrollView style={styles.contentArea}>
          {/* Continue Shopping Link */}
          <TouchableOpacity 
            style={styles.continueLink}
            onPress={onClose}
          >
            <Ionicons name="arrow-back" size={16} color="#FF1493" />
            <Text style={styles.continueLinkText}>Continue Shopping</Text>
          </TouchableOpacity>

          {/* Cart Content */}
          {cartItems.length === 0 ? (
            /* Empty Cart */
            <View style={styles.emptyCart}>
              <View style={styles.emptyCartIcon}>
                <Ionicons name="cart-outline" size={80} color="#FF1493" />
                <View style={styles.emptyBadge}>
                  <Ionicons name="close" size={30} color="#fff" />
                </View>
              </View>
              
              <Text style={styles.emptyTitle}>Your cart is empty!</Text>
              <Text style={styles.emptySubtitle}>
                Add some beautiful scrunchies to your cart.
              </Text>

              <TouchableOpacity 
                style={styles.startShoppingButton}
                onPress={onClose}
              >
                <Text style={styles.startShoppingText}>Start Shopping</Text>
              </TouchableOpacity>
            </View>
          ) : (
            /* Cart with Items */
            <View style={styles.cartContent}>
              <Text style={styles.cartTitle}>Shopping Cart</Text>

              {/* Cart Items */}
              <View style={styles.cartItems}>
                {/* Header Row */}
                <View style={styles.cartHeader}>
                  <Text style={[styles.headerText, { flex: 2 }]}>PRODUCT</Text>
                  <Text style={[styles.headerText, { flex: 1, textAlign: 'center' }]}>PRICE</Text>
                  <Text style={[styles.headerText, { flex: 1, textAlign: 'center' }]}>QUANTITY</Text>
                  <Text style={[styles.headerText, { flex: 1, textAlign: 'right' }]}>TOTAL</Text>
                </View>

                {/* Cart Items List */}
                {cartItems.map((item) => (
                  <View key={item.id} style={styles.cartItem}>
                    <View style={styles.productInfo}>
                      <Image source={item.image} style={styles.productImage} />
                      <View style={styles.productDetails}>
                        <Text style={styles.productName}>{item.name}</Text>
                        <Text style={styles.productCategory}>{item.category}</Text>
                      </View>
                    </View>

                    <View style={styles.priceSection}>
                      <Text style={styles.priceText}>Rs. {item.price}</Text>
                    </View>

                    <View style={styles.quantitySection}>
                      <TouchableOpacity
                        style={styles.quantityBtn}
                        onPress={() => updateQuantity(item.id, item.quantity - 1)}
                      >
                        <Ionicons name="remove" size={16} color="#333" />
                      </TouchableOpacity>
                      <Text style={styles.quantityText}>{item.quantity}</Text>
                      <TouchableOpacity
                        style={styles.quantityBtn}
                        onPress={() => updateQuantity(item.id, item.quantity + 1)}
                      >
                        <Ionicons name="add" size={16} color="#333" />
                      </TouchableOpacity>
                    </View>

                    <View style={styles.totalSection}>
                      <Text style={styles.totalText}>Rs. {item.price * item.quantity}</Text>
                      <TouchableOpacity
                        style={styles.removeBtn}
                        onPress={() => handleRemoveItem(item.id, item.name)}
                      >
                        <Ionicons name="trash-outline" size={20} color="#FF1493" />
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </View>

              {/* Subtotal Section */}
              <View style={styles.subtotalSection}>
                <Text style={styles.subtotalTitle}>SUBTOTAL</Text>
                
                <View style={styles.subtotalRow}>
                  <Text style={styles.subtotalLabel}>Subtotal:</Text>
                  <Text style={styles.subtotalValue}>Rs. {getCartTotal()}</Text>
                </View>

                <View style={styles.subtotalRow}>
                  <Text style={styles.subtotalLabel}>Shipping:</Text>
                  <Text style={styles.subtotalValue}>Rs. {SHIPPING_COST}</Text>
                </View>

                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total:</Text>
                  <Text style={styles.totalValue}>Rs. {getCartTotal() + SHIPPING_COST}</Text>
                </View>

                <Text style={styles.shippingNote}>
                  All charges are billed in PKR. Shipping calculated at checkout.
                </Text>

                <TouchableOpacity 
                  style={styles.checkoutButton}
                  onPress={handleCheckout}
                >
                  <Text style={styles.checkoutText}>Check Out</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Footer Social Icons */}
          <View style={styles.footer}>
            <TouchableOpacity style={styles.socialIcon}>
              <Ionicons name="logo-whatsapp" size={28} color="#25D366" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialIcon}>
              <Ionicons name="logo-instagram" size={28} color="#E4405F" />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 12,
    paddingTop: Platform.OS === 'ios' ? 50 : StatusBar.currentHeight + 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    zIndex: 100,
  },
  menuIcon: {
    padding: 5,
    width: 40,
  },
  logo: {
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 3,
    color: '#FF1493',
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  rightIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    marginLeft: 15,
    position: 'relative',
    padding: 5,
  },
  badge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF1493',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  mainContent: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 9,
  },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#fff',
    zIndex: 10,
    elevation: 16,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  sidebarHeader: {
    backgroundColor: '#FFB6C1',
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sidebarTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: 1,
  },
  menuScroll: {
    flex: 1,
  },
  menuItem: {
    paddingVertical: 16,
    paddingHorizontal: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  menuText: {
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
  },
  activeMenu: {
    color: '#FF1493',
    fontWeight: '600',
  },
  dropdown: {
    backgroundColor: '#FFF0F5',
    paddingLeft: 20,
  },
  dropdownItem: {
    paddingVertical: 14,
    paddingHorizontal: 25,
  },
  dropdownText: {
    fontSize: 14,
    color: '#666',
  },
  contentArea: {
    flex: 1,
    backgroundColor: '#FFF0F5',
  },
  continueLink: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
  },
  continueLinkText: {
    color: '#FF1493',
    fontSize: 14,
    marginLeft: 5,
    fontWeight: '500',
  },
  emptyCart: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 30,
  },
  emptyCartIcon: {
    position: 'relative',
    marginBottom: 30,
  },
  emptyBadge: {
    position: 'absolute',
    top: -10,
    right: -10,
    backgroundColor: '#FF1493',
    borderRadius: 25,
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF1493',
    marginBottom: 10,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
  },
  startShoppingButton: {
    backgroundColor: '#FF1493',
    paddingVertical: 15,
    paddingHorizontal: 50,
    borderRadius: 25,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  startShoppingText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cartContent: {
    padding: 15,
  },
  cartTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF1493',
    marginBottom: 20,
    textAlign: 'center',
  },
  cartItems: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },
  cartHeader: {
    flexDirection: 'row',
    paddingBottom: 15,
    borderBottomWidth: 2,
    borderBottomColor: '#f0f0f0',
    marginBottom: 15,
  },
  headerText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FF1493',
  },
  cartItem: {
    flexDirection: 'row',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
    alignItems: 'center',
  },
  productInfo: {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  productImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 10,
  },
  productDetails: {
    flex: 1,
  },
  productName: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 11,
    color: '#999',
  },
  priceSection: {
    flex: 1,
    alignItems: 'center',
  },
  priceText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#333',
  },
  quantitySection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  quantityBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#FFF0F5',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FFD0E0',
  },
  quantityText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    minWidth: 20,
    textAlign: 'center',
  },
  totalSection: {
    flex: 1,
    alignItems: 'flex-end',
  },
  totalText: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#FF1493',
    marginBottom: 5,
  },
  removeBtn: {
    padding: 5,
  },
  subtotalSection: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
  },
  subtotalTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF1493',
    marginBottom: 15,
    textAlign: 'center',
  },
  subtotalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  subtotalLabel: {
    fontSize: 14,
    color: '#666',
  },
  subtotalValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 15,
    borderTopWidth: 2,
    borderTopColor: '#f0f0f0',
    marginTop: 10,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF1493',
  },
  shippingNote: {
    fontSize: 11,
    color: '#999',
    textAlign: 'center',
    marginTop: 15,
    marginBottom: 20,
  },
  checkoutButton: {
    backgroundColor: '#FF1493',
    paddingVertical: 15,
    borderRadius: 25,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  checkoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 25,
    marginTop: 40,
    gap: 30,
  },
  socialIcon: {
    padding: 5,
  },
});