// Supabase Configuration - Fluff and Tie Shop
const SUPABASE_URL = 'https://qcktqreiykdqyockmujk.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFja3RxcmVpeWtkcXlvY2ttdWprIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2MTg4NTAsImV4cCI6MjA4MzE5NDg1MH0.8o0D8cGMzhXXw89fPLMYeCxsvUyvP28emH-J0di8nTk';

class SupabaseClient {
  constructor(url, key) {
    this.url = url;
    this.key = key;
    this.headers = {
      'Content-Type': 'application/json',
      'apikey': key,
      'Authorization': `Bearer ${key}`,
      'Prefer': 'return=representation'
    };
  }

  // ==================== ORDERS ====================

  async createOrder(orderData) {
    try {
      const formattedOrder = {
        customer_name: orderData.customer_name,
        email: orderData.email,
        phone: orderData.phone,
        address: orderData.address,
        items: orderData.items,
        total: parseFloat(orderData.total)
      };

      console.log('📦 Sending to Supabase:', formattedOrder);

      const response = await fetch(`${this.url}/rest/v1/orders`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(formattedOrder)
      });
      
      if (!response.ok) {
        const error = await response.text();
        console.error('❌ Supabase error:', error);
        throw new Error(`Failed to create order: ${error}`);
      }
      
      const result = await response.json();
      console.log('✅ Order created:', result);
      return result[0];
    } catch (error) {
      console.error('❌ Error creating order:', error);
      throw error;
    }
  }

  async getOrders(limit = 50) {
    try {
      const response = await fetch(
        `${this.url}/rest/v1/orders?select=*&order=created_at.desc&limit=${limit}`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to fetch orders');
      return await response.json();
    } catch (error) {
      console.error('Error fetching orders:', error);
      throw error;
    }
  }

  async getOrderById(id) {
    try {
      const response = await fetch(
        `${this.url}/rest/v1/orders?id=eq.${id}&select=*`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to fetch order');
      const data = await response.json();
      return data[0];
    } catch (error) {
      console.error('Error fetching order:', error);
      throw error;
    }
  }

  // ==================== PRODUCTS ====================

  async getProducts() {
    try {
      const response = await fetch(
        `${this.url}/rest/v1/products?select=*`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to fetch products');
      const data = await response.json();
      console.log('✅ Products fetched:', data);
      return data;
    } catch (error) {
      console.error('❌ Error fetching products:', error);
      throw error;
    }
  }

  async getProductsByCategory(category) {
    try {
      const response = await fetch(
        `${this.url}/rest/v1/products?category=eq.${category}&select=*`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to fetch products');
      const data = await response.json();
      console.log(`✅ ${category} products fetched:`, data);
      return data;
    } catch (error) {
      console.error(`❌ Error fetching ${category} products:`, error);
      throw error;
    }
  }

  async getProductById(id) {
    try {
      const response = await fetch(
        `${this.url}/rest/v1/products?id=eq.${id}&select=*`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to fetch product');
      const data = await response.json();
      return data[0];
    } catch (error) {
      console.error('❌ Error fetching product:', error);
      throw error;
    }
  }

  // ✅ NEW: Search products by name
  async searchProducts(searchTerm) {
    try {
      if (!searchTerm || searchTerm.trim().length === 0) {
        return [];
      }

      // Search in product name (case-insensitive)
      const response = await fetch(
        `${this.url}/rest/v1/products?name=ilike.*${searchTerm}*&select=*`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to search products');
      const data = await response.json();
      console.log(`🔍 Search results for "${searchTerm}":`, data);
      return data;
    } catch (error) {
      console.error('❌ Error searching products:', error);
      throw error;
    }
  }

  // ==================== CONTACTS ====================

  async createContact(contactData) {
    try {
      const formattedContact = {
        name: contactData.name,
        email: contactData.email,
        message: contactData.message
      };

      console.log('📧 Sending contact to Supabase:', formattedContact);

      const response = await fetch(`${this.url}/rest/v1/contacts`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(formattedContact)
      });
      
      if (!response.ok) {
        const error = await response.text();
        console.error('❌ Supabase error:', error);
        throw new Error(`Failed to create contact: ${error}`);
      }
      
      const result = await response.json();
      console.log('✅ Contact created:', result);
      return result[0];
    } catch (error) {
      console.error('❌ Error creating contact:', error);
      throw error;
    }
  }

  async getContacts(limit = 50) {
    try {
      const response = await fetch(
        `${this.url}/rest/v1/contacts?select=*&order=created_at.desc&limit=${limit}`,
        {
          method: 'GET',
          headers: this.headers
        }
      );
      
      if (!response.ok) throw new Error('Failed to fetch contacts');
      return await response.json();
    } catch (error) {
      console.error('Error fetching contacts:', error);
      throw error;
    }
  }
}

export const supabase = new SupabaseClient(SUPABASE_URL, SUPABASE_ANON_KEY);
export { SupabaseClient, SUPABASE_URL, SUPABASE_ANON_KEY };