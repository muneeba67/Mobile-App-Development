import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
  StatusBar,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useCart } from './CartContext';

export default function ProductDetailScreen({ product, onClose, onOpenCart, onOpenContact }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [shopExpanded, setShopExpanded] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const { addToCart, getCartCount } = useCart();

  if (!product) {
    return (
      <View style={styles.container}>
        <Text>No product selected</Text>
      </View>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    Alert.alert(
      '✅ Success!',
      `${product.name} added to cart!`,
      [
        { text: 'Continue Shopping', onPress: onClose, style: 'cancel' },
        { text: 'View Cart', onPress: onOpenCart }
      ]
    );
  };

  const handleBuyNow = () => {
    handleAddToCart();
    setTimeout(() => {
      onOpenCart();
    }, 500);
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFB6C1" />
      
      <LinearGradient
        colors={['#FFB6C1', '#FFDAB9', '#98D8C8', '#DDA0DD']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.header}
      >
        <TouchableOpacity
          style={styles.menuIcon}
          onPress={() => setMenuOpen(!menuOpen)}
        >
          <Ionicons name={menuOpen ? "close" : "menu"} size={28} color="#333" />
        </TouchableOpacity>

        <Text style={styles.logo}>FLUFF N TIE</Text>

        <View style={styles.rightIcons}>
          <TouchableOpacity style={styles.iconButton}>
            <Ionicons name="search" size={24} color="#333" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.iconButton}
            onPress={onOpenCart}
          >
            <Ionicons name="cart" size={24} color="#333" />
            {getCartCount() > 0 && (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{getCartCount()}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </LinearGradient>

      <View style={styles.mainContent}>
        {menuOpen && (
          <>
            <TouchableOpacity
              style={styles.overlay}
              activeOpacity={1}
              onPress={() => setMenuOpen(false)}
            />
            
            <View style={styles.sidebar}>
              <View style={styles.sidebarHeader}>
                <Text style={styles.sidebarTitle}>Menu</Text>
              </View>

              <ScrollView style={styles.menuScroll}>
                <TouchableOpacity 
                  style={styles.menuItem}
                  onPress={() => {
                    setMenuOpen(false);
                    onClose();
                  }}
                >
                  <Text style={styles.menuText}>Home</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.menuItem}
                  onPress={() => setShopExpanded(!shopExpanded)}
                >
                  <View style={styles.menuItemContent}>
                    <Text style={[styles.menuText, styles.activeMenu]}>Shop</Text>
                    <Ionicons
                      name={shopExpanded ? 'chevron-down' : 'chevron-forward'}
                      size={20}
                      color="#FF1493"
                    />
                  </View>
                </TouchableOpacity>

                {shopExpanded && (
                  <View style={styles.dropdown}>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Floral Prints Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Velvet Scrunchies</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.dropdownItem}
                      onPress={() => setMenuOpen(false)}
                    >
                      <Text style={styles.dropdownText}>Silk Scrunchies</Text>
                    </TouchableOpacity>
                  </View>
                )}

                <TouchableOpacity 
                  style={styles.menuItem}
                  onPress={() => {
                    setMenuOpen(false);
                    if (onOpenContact) {
                      onClose();
                      setTimeout(() => onOpenContact(), 100);
                    }
                  }}
                >
                  <Text style={styles.menuText}>Contact</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          </>
        )}

        <ScrollView style={styles.contentArea} showsVerticalScrollIndicator={false}>
          <TouchableOpacity 
            style={styles.backLink}
            onPress={onClose}
          >
            <Ionicons name="arrow-back" size={16} color="#FF1493" />
            <Text style={styles.backLinkText}>Back to Shop</Text>
          </TouchableOpacity>

          <View style={styles.productContainer}>
            <Image source={product.image} style={styles.productImage} />
            
            <View style={styles.productInfo}>
              <Text style={styles.productName}>{product.name}</Text>
              <Text style={styles.productPrice}>Rs. {product.price}</Text>
              
              {product.category && (
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryText}>{product.category}</Text>
                </View>
              )}

              <Text style={styles.productDescription}>
                {product.description || 'Beautiful scrunchie that adds elegance to your hairstyle. Soft on hair and perfect for all occasions.'}
              </Text>

              <View style={styles.featuresSection}>
                <Text style={styles.featuresTitle}>Features:</Text>
                <View style={styles.featureItem}>
                  <Ionicons name="checkmark-circle" size={20} color="#FF1493" />
                  <Text style={styles.featureText}>Premium quality material</Text>
                </View>
                <View style={styles.featureItem}>
                  <Ionicons name="checkmark-circle" size={20} color="#FF1493" />
                  <Text style={styles.featureText}>Gentle on hair</Text>
                </View>
                <View style={styles.featureItem}>
                  <Ionicons name="checkmark-circle" size={20} color="#FF1493" />
                  <Text style={styles.featureText}>Perfect for all hair types</Text>
                </View>
                <View style={styles.featureItem}>
                  <Ionicons name="checkmark-circle" size={20} color="#FF1493" />
                  <Text style={styles.featureText}>Elegant design</Text>
                </View>
              </View>

              <View style={styles.quantitySection}>
                <Text style={styles.quantityLabel}>Quantity:</Text>
                <View style={styles.quantityControls}>
                  <TouchableOpacity 
                    style={styles.quantityBtn}
                    onPress={() => setQuantity(Math.max(1, quantity - 1))}
                  >
                    <Ionicons name="remove" size={20} color="#333" />
                  </TouchableOpacity>
                  <Text style={styles.quantityValue}>{quantity}</Text>
                  <TouchableOpacity 
                    style={styles.quantityBtn}
                    onPress={() => setQuantity(quantity + 1)}
                  >
                    <Ionicons name="add" size={20} color="#333" />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.actionButtons}>
                <TouchableOpacity 
                  style={styles.addToCartButton}
                  onPress={handleAddToCart}
                >
                  <Ionicons name="cart" size={20} color="#fff" />
                  <Text style={styles.buttonText}>ADD TO CART</Text>
                </TouchableOpacity>

                <TouchableOpacity 
                  style={styles.buyNowButton}
                  onPress={handleBuyNow}
                >
                  <Text style={styles.buyNowText}>BUY NOW</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>© 2025, Fluff N Tie</Text>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 12,
    paddingTop: Platform.OS === 'ios' ? 50 : StatusBar.currentHeight + 10,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    zIndex: 100,
  },
  menuIcon: {
    padding: 5,
    width: 40,
  },
  logo: {
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 3,
    color: '#FF1493',
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  rightIcons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconButton: {
    marginLeft: 15,
    position: 'relative',
    padding: 5,
  },
  badge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#FF1493',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  mainContent: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 9,
  },
  sidebar: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#fff',
    zIndex: 10,
    elevation: 16,
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  sidebarHeader: {
    backgroundColor: '#FFB6C1',
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  sidebarTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: 1,
  },
  menuScroll: {
    flex: 1,
  },
  menuItem: {
    paddingVertical: 16,
    paddingHorizontal: 25,
    borderBottomWidth: 1,
    borderBottomColor: '#f5f5f5',
  },
  menuItemContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  menuText: {
    fontSize: 16,
    color: '#333',
    fontWeight: '500',
  },
  activeMenu: {
    color: '#FF1493',
    fontWeight: '600',
  },
  dropdown: {
    backgroundColor: '#FFF0F5',
    paddingLeft: 20,
  },
  dropdownItem: {
    paddingVertical: 14,
    paddingHorizontal: 25,
  },
  dropdownText: {
    fontSize: 14,
    color: '#666',
  },
  contentArea: {
    flex: 1,
    backgroundColor: '#FFF5F8',
  },
  backLink: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
  },
  backLinkText: {
    color: '#FF1493',
    fontSize: 14,
    marginLeft: 5,
    fontWeight: '500',
  },
  productContainer: {
    backgroundColor: '#fff',
    borderRadius: 20,
    margin: 15,
    padding: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  productImage: {
    width: '100%',
    height: 350,
    borderRadius: 15,
    marginBottom: 20,
    resizeMode: 'cover',
  },
  productInfo: {
    gap: 15,
  },
  productName: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#333',
  },
  productPrice: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF1493',
  },
  categoryBadge: {
    backgroundColor: '#FFE4F1',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  categoryText: {
    color: '#FF1493',
    fontSize: 12,
    fontWeight: '600',
  },
  productDescription: {
    fontSize: 15,
    color: '#666',
    lineHeight: 22,
    marginTop: 5,
  },
  featuresSection: {
    marginTop: 10,
  },
  featuresTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 10,
  },
  quantitySection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 15,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  quantityLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  quantityBtn: {
    width: 35,
    height: 35,
    borderRadius: 17.5,
    backgroundColor: '#FFF0F5',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#FFD0E0',
  },
  quantityValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    minWidth: 30,
    textAlign: 'center',
  },
  actionButtons: {
    gap: 12,
    marginTop: 20,
  },
  addToCartButton: {
    backgroundColor: '#FF1493',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 25,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    gap: 10,
  },
  buyNowButton: {
    backgroundColor: '#333',
    paddingVertical: 16,
    borderRadius: 25,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  buyNowText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 25,
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    marginTop: 20,
    backgroundColor: '#fafafa',
  },
  footerText: {
    color: '#888',
    fontSize: 13,
    letterSpacing: 0.5,
  },
});