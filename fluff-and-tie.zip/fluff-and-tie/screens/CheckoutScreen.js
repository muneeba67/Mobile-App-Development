import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './supabaseClient';
import { useCart } from './CartContext';

export default function CheckoutScreen({ onClose, onOpenCart }) {
  const [loading, setLoading] = useState(false);
  const { cartItems, getCartTotal, clearCart } = useCart();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipCode: ''
  });

  const SHIPPING_COST = 190;
  const totalPrice = getCartTotal() + SHIPPING_COST;

  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = () => {
    const { name, email, phone, address, city, zipCode } = formData;
    
    if (!name.trim()) {
      Alert.alert('⚠️ Required Field', 'Please enter your name');
      return false;
    }
    if (!email.trim() || !email.includes('@')) {
      Alert.alert('⚠️ Invalid Email', 'Please enter a valid email address');
      return false;
    }
    if (!phone.trim() || phone.length < 10) {
      Alert.alert('⚠️ Invalid Phone', 'Please enter a valid 10+ digit phone number');
      return false;
    }
    if (!address.trim()) {
      Alert.alert('⚠️ Required Field', 'Please enter your delivery address');
      return false;
    }
    if (!city.trim()) {
      Alert.alert('⚠️ Required Field', 'Please enter your city');
      return false;
    }
    if (!zipCode.trim()) {
      Alert.alert('⚠️ Required Field', 'Please enter your zip code');
      return false;
    }
    
    return true;
  };

  const handlePlaceOrder = async () => {
    if (loading) {
      console.log('⚠️ Already processing order...');
      return;
    }

    if (cartItems.length === 0) {
      Alert.alert('🛒 Empty Cart', 'Please add items to cart before checkout');
      return;
    }

    if (!validateForm()) return;

    setLoading(true);

    try {
      const formattedItems = cartItems.map(item => ({
        id: item.id,
        name: item.name,
        category: item.category,
        price: item.price,
        quantity: item.quantity,
        total: item.price * item.quantity
      }));

      // ✅ ORDER DATA WITH STATUS
      const orderData = {
        customer_name: formData.name,
        email: formData.email,
        phone: formData.phone,
        address: `${formData.address}, ${formData.city}, ${formData.zipCode}`,
        items: formattedItems,
        total: totalPrice,
        status: 'pending' // ✅ DEFAULT STATUS
      };

      console.log('📦 Placing order:', orderData);

      const result = await supabase.createOrder(orderData);

      console.log('✅ Order created successfully:', result);

      // ✅ RESET FORM
      setFormData({
        name: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        zipCode: ''
      });

      // ✅ CLEAR CART
      clearCart();

      // ✅ SUCCESS ALERT WITH STATUS INFO
      Alert.alert(
        '🎉 Order Placed Successfully!',
        `Thank you ${formData.name}!\n\n` +
        `📋 Order ID: #${result.id}\n` +
        `📊 Status: PENDING\n` +
        `💰 Total Amount: Rs. ${totalPrice}\n` +
        `📦 Items: ${cartItems.length} product(s)\n\n` +
        `📞 We'll call you at ${formData.phone} within 24 hours to confirm your order!\n\n` +
        `📍 Delivery Address:\n${formData.address}, ${formData.city}, ${formData.zipCode}\n\n` +
        `⏰ Expected Delivery: 3-5 business days`,
        [
          {
            text: '✓ OK',
            onPress: () => {
              if (onClose) onClose();
            }
          }
        ],
        { cancelable: false }
      );
    } catch (error) {
      console.error('❌ Order placement error:', error);
      
      Alert.alert(
        '❌ Order Failed',
        `Sorry, we couldn't process your order.\n\n` +
        `Error: ${error.message}\n\n` +
        `Please check your internet connection and try again.\n\n` +
        `If the problem persists, contact support at 0343 6689390.`,
        [
          { text: 'Retry', onPress: () => handlePlaceOrder() },
          { text: 'Cancel', style: 'cancel' }
        ]
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onClose}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Checkout</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Order Summary */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📋 Order Summary</Text>
        {cartItems.map((item, index) => (
          <View key={index} style={styles.orderItem}>
            <Text style={styles.itemName}>
              {item.name} × {item.quantity}
            </Text>
            <Text style={styles.itemPrice}>Rs. {item.price * item.quantity}</Text>
          </View>
        ))}
        
        <View style={styles.orderItem}>
          <Text style={styles.itemName}>Shipping</Text>
          <Text style={styles.itemPrice}>Rs. {SHIPPING_COST}</Text>
        </View>

        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total Amount:</Text>
          <Text style={styles.totalPrice}>Rs. {totalPrice}</Text>
        </View>
      </View>

      {/* Customer Information */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>👤 Customer Information</Text>
        
        <Text style={styles.inputLabel}>Full Name *</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter your full name"
          value={formData.name}
          onChangeText={(text) => updateField('name', text)}
        />
        
        <Text style={styles.inputLabel}>Email Address *</Text>
        <TextInput
          style={styles.input}
          placeholder="your.email@example.com"
          value={formData.email}
          onChangeText={(text) => updateField('email', text)}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        
        <Text style={styles.inputLabel}>Phone Number *</Text>
        <TextInput
          style={styles.input}
          placeholder="03XX-XXXXXXX"
          value={formData.phone}
          onChangeText={(text) => updateField('phone', text)}
          keyboardType="phone-pad"
        />
      </View>

      {/* Delivery Address */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📦 Delivery Address</Text>
        
        <Text style={styles.inputLabel}>Street Address *</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="House/Flat no., Street name, Area"
          value={formData.address}
          onChangeText={(text) => updateField('address', text)}
          multiline
          numberOfLines={3}
        />
        
        <View style={styles.row}>
          <View style={styles.halfWidth}>
            <Text style={styles.inputLabel}>City *</Text>
            <TextInput
              style={styles.input}
              placeholder="City"
              value={formData.city}
              onChangeText={(text) => updateField('city', text)}
            />
          </View>
          
          <View style={styles.halfWidth}>
            <Text style={styles.inputLabel}>Zip Code *</Text>
            <TextInput
              style={styles.input}
              placeholder="00000"
              value={formData.zipCode}
              onChangeText={(text) => updateField('zipCode', text)}
              keyboardType="numeric"
            />
          </View>
        </View>
      </View>

      {/* Payment Info */}
      <View style={styles.paymentInfo}>
        <Ionicons name="cash-outline" size={24} color="#2e7d32" />
        <Text style={styles.paymentText}>Payment: Cash on Delivery</Text>
      </View>

      {/* ✅ ORDER STATUS INFO */}
      <View style={styles.statusInfo}>
        <Ionicons name="information-circle" size={20} color="#FF1493" />
        <View style={styles.statusTextContainer}>
          <Text style={styles.statusTitle}>Order Status Tracking:</Text>
          <Text style={styles.statusText}>• Pending → Confirmed → Shipped → Delivered</Text>
          <Text style={styles.statusText}>• You'll receive confirmation call within 24 hours</Text>
        </View>
      </View>

      {/* Place Order Button */}
      <TouchableOpacity
        style={[styles.placeOrderButton, loading && styles.buttonDisabled]}
        onPress={handlePlaceOrder}
        disabled={loading}
        activeOpacity={0.8}
      >
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator color="#fff" size="small" />
            <Text style={styles.loadingText}>Processing Order...</Text>
          </View>
        ) : (
          <>
            <Ionicons name="checkmark-circle" size={26} color="#fff" />
            <Text style={styles.placeOrderText}>Place Order - Rs. {totalPrice}</Text>
          </>
        )}
      </TouchableOpacity>

      {/* Security Note */}
      <View style={styles.securityNote}>
        <Ionicons name="shield-checkmark" size={16} color="#666" />
        <Text style={styles.securityText}>
          Your information is secure and will only be used for order processing
        </Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    marginTop: 40,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  section: {
    backgroundColor: '#fff',
    margin: 16,
    marginBottom: 8,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  itemName: {
    fontSize: 15,
    color: '#555',
    flex: 1,
  },
  itemPrice: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 2,
    borderTopColor: '#FF1493',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF1493',
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#555',
    marginBottom: 6,
    marginTop: 4,
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    fontSize: 15,
    marginBottom: 12,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  halfWidth: {
    flex: 1,
  },
  paymentInfo: {
    backgroundColor: '#e8f5e9',
    marginHorizontal: 16,
    marginVertical: 8,
    padding: 16,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  paymentText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2e7d32',
  },
  // ✅ NEW: STATUS INFO STYLES
  statusInfo: {
    backgroundColor: '#FFF0F5',
    marginHorizontal: 16,
    marginVertical: 8,
    padding: 16,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#FF1493',
  },
  statusTextContainer: {
    flex: 1,
  },
  statusTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FF1493',
    marginBottom: 6,
  },
  statusText: {
    fontSize: 12,
    color: '#666',
    marginBottom: 3,
    lineHeight: 18,
  },
  placeOrderButton: {
    backgroundColor: '#FF1493',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 18,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 25,
    shadowColor: '#FF1493',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  loadingText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  placeOrderText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  securityNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 16,
    marginTop: 12,
    gap: 6,
  },
  securityText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    flex: 1,
  },
});